/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : 127.0.0.1:9306
 Source Schema         : split

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 27/04/2021 13:26:14
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for test_0
-- ----------------------------
DROP TABLE IF EXISTS `test_0`;
CREATE TABLE "test_0" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_0
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_1
-- ----------------------------
DROP TABLE IF EXISTS `test_1`;
CREATE TABLE "test_1" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_1
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_2
-- ----------------------------
DROP TABLE IF EXISTS `test_2`;
CREATE TABLE "test_2" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_2
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_3
-- ----------------------------
DROP TABLE IF EXISTS `test_3`;
CREATE TABLE "test_3" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_3
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_4
-- ----------------------------
DROP TABLE IF EXISTS `test_4`;
CREATE TABLE "test_4" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_4
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_5
-- ----------------------------
DROP TABLE IF EXISTS `test_5`;
CREATE TABLE "test_5" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_5
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_6
-- ----------------------------
DROP TABLE IF EXISTS `test_6`;
CREATE TABLE "test_6" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_6
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_7
-- ----------------------------
DROP TABLE IF EXISTS `test_7`;
CREATE TABLE "test_7" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_7
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_8
-- ----------------------------
DROP TABLE IF EXISTS `test_8`;
CREATE TABLE "test_8" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_8
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for test_9
-- ----------------------------
DROP TABLE IF EXISTS `test_9`;
CREATE TABLE "test_9" (
  "id" bigint(20) NOT NULL,
  "name" varchar(255) DEFAULT NULL,
  "create_time" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id") USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of test_9
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
