/*
 Navicat Premium Data Transfer

 Source Server         : gaorongyi.cn_8
 Source Server Type    : MySQL
 Source Server Version : 80023
 Source Host           : www.gaorongyi.cn:9407
 Source Schema         : split

 Target Server Type    : MySQL
 Target Server Version : 80023
 File Encoding         : 65001

 Date: 27/04/2021 00:52:14
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sequence
-- ----------------------------
DROP TABLE IF EXISTS `sequence`;
CREATE TABLE `sequence`  (
  `seq_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `current_val` bigint NOT NULL,
  `increment_val` bigint NOT NULL DEFAULT 1,
  PRIMARY KEY (`seq_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sequence
-- ----------------------------
INSERT INTO `sequence` VALUES ('test_seq', 104, 1);

-- ----------------------------
-- Table structure for test
-- ----------------------------
DROP TABLE IF EXISTS `test`;
CREATE TABLE `test`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test
-- ----------------------------
INSERT INTO `test` VALUES (104, '3715', '2021-04-27 00:50:46');

-- ----------------------------
-- Table structure for test_0
-- ----------------------------
DROP TABLE IF EXISTS `test_0`;
CREATE TABLE `test_0`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_0
-- ----------------------------
INSERT INTO `test_0` VALUES (57, '3100', '2021-04-27 00:49:31');
INSERT INTO `test_0` VALUES (69, '6920', '2021-04-27 00:49:31');
INSERT INTO `test_0` VALUES (78, '5180', '2021-04-27 00:49:31');
INSERT INTO `test_0` VALUES (81, '9350', '2021-04-27 00:49:31');
INSERT INTO `test_0` VALUES (88, '2260', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_1
-- ----------------------------
DROP TABLE IF EXISTS `test_1`;
CREATE TABLE `test_1`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_1
-- ----------------------------
INSERT INTO `test_1` VALUES (59, '5821', '2021-04-27 00:49:31');
INSERT INTO `test_1` VALUES (60, '251', '2021-04-27 00:49:31');
INSERT INTO `test_1` VALUES (72, '1361', '2021-04-27 00:49:31');
INSERT INTO `test_1` VALUES (74, '4321', '2021-04-27 00:49:31');
INSERT INTO `test_1` VALUES (89, '6831', '2021-04-27 00:49:31');
INSERT INTO `test_1` VALUES (102, '6321', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_2
-- ----------------------------
DROP TABLE IF EXISTS `test_2`;
CREATE TABLE `test_2`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_2
-- ----------------------------
INSERT INTO `test_2` VALUES (53, '6182', '2021-04-27 00:49:31');
INSERT INTO `test_2` VALUES (55, '7472', '2021-04-27 00:49:31');
INSERT INTO `test_2` VALUES (58, '6072', '2021-04-27 00:49:31');
INSERT INTO `test_2` VALUES (68, '6382', '2021-04-27 00:49:31');
INSERT INTO `test_2` VALUES (73, '7022', '2021-04-27 00:49:31');
INSERT INTO `test_2` VALUES (79, '852', '2021-04-27 00:49:31');
INSERT INTO `test_2` VALUES (84, '3602', '2021-04-27 00:49:31');
INSERT INTO `test_2` VALUES (87, '4602', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_3
-- ----------------------------
DROP TABLE IF EXISTS `test_3`;
CREATE TABLE `test_3`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_3
-- ----------------------------
INSERT INTO `test_3` VALUES (56, '9173', '2021-04-27 00:49:31');
INSERT INTO `test_3` VALUES (65, '4543', '2021-04-27 00:49:31');
INSERT INTO `test_3` VALUES (66, '2033', '2021-04-27 00:49:31');
INSERT INTO `test_3` VALUES (71, '4233', '2021-04-27 00:49:31');
INSERT INTO `test_3` VALUES (76, '7813', '2021-04-27 00:49:31');
INSERT INTO `test_3` VALUES (97, '5193', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_4
-- ----------------------------
DROP TABLE IF EXISTS `test_4`;
CREATE TABLE `test_4`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_4
-- ----------------------------
INSERT INTO `test_4` VALUES (62, '2524', '2021-04-27 00:49:31');
INSERT INTO `test_4` VALUES (93, '6444', '2021-04-27 00:49:31');
INSERT INTO `test_4` VALUES (95, '9104', '2021-04-27 00:49:31');
INSERT INTO `test_4` VALUES (98, '9614', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_5
-- ----------------------------
DROP TABLE IF EXISTS `test_5`;
CREATE TABLE `test_5`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_5
-- ----------------------------
INSERT INTO `test_5` VALUES (61, '8585', '2021-04-27 00:49:31');
INSERT INTO `test_5` VALUES (75, '1265', '2021-04-27 00:49:31');
INSERT INTO `test_5` VALUES (83, '2715', '2021-04-27 00:49:31');
INSERT INTO `test_5` VALUES (92, '7175', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_6
-- ----------------------------
DROP TABLE IF EXISTS `test_6`;
CREATE TABLE `test_6`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_6
-- ----------------------------
INSERT INTO `test_6` VALUES (54, '6336', '2021-04-27 00:49:31');
INSERT INTO `test_6` VALUES (67, '9636', '2021-04-27 00:49:31');
INSERT INTO `test_6` VALUES (77, '2936', '2021-04-27 00:49:31');
INSERT INTO `test_6` VALUES (85, '8726', '2021-04-27 00:49:31');
INSERT INTO `test_6` VALUES (90, '4616', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_7
-- ----------------------------
DROP TABLE IF EXISTS `test_7`;
CREATE TABLE `test_7`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_7
-- ----------------------------
INSERT INTO `test_7` VALUES (64, '7917', '2021-04-27 00:49:31');
INSERT INTO `test_7` VALUES (99, '1787', '2021-04-27 00:49:31');
INSERT INTO `test_7` VALUES (100, '3887', '2021-04-27 00:49:31');
INSERT INTO `test_7` VALUES (101, '5617', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_8
-- ----------------------------
DROP TABLE IF EXISTS `test_8`;
CREATE TABLE `test_8`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_8
-- ----------------------------
INSERT INTO `test_8` VALUES (63, '7168', '2021-04-27 00:49:31');
INSERT INTO `test_8` VALUES (70, '8748', '2021-04-27 00:49:31');
INSERT INTO `test_8` VALUES (82, '8148', '2021-04-27 00:49:31');
INSERT INTO `test_8` VALUES (94, '2708', '2021-04-27 00:49:31');

-- ----------------------------
-- Table structure for test_9
-- ----------------------------
DROP TABLE IF EXISTS `test_9`;
CREATE TABLE `test_9`  (
  `id` bigint NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_9
-- ----------------------------
INSERT INTO `test_9` VALUES (80, '7589', '2021-04-27 00:49:31');
INSERT INTO `test_9` VALUES (86, '4309', '2021-04-27 00:49:31');
INSERT INTO `test_9` VALUES (91, '3469', '2021-04-27 00:49:31');
INSERT INTO `test_9` VALUES (96, '2739', '2021-04-27 00:49:31');

-- ----------------------------
-- Function structure for currval
-- ----------------------------
DROP FUNCTION IF EXISTS `currval`;
delimiter ;;
CREATE FUNCTION `currval`(v_seq_name VARCHAR(50))
 RETURNS bigint
begin     
    declare value bigint;      
    set value = 0;      
    select current_val into value  from sequence where seq_name = v_seq_name;
   return value;
end
;;
delimiter ;

-- ----------------------------
-- Function structure for nextval
-- ----------------------------
DROP FUNCTION IF EXISTS `nextval`;
delimiter ;;
CREATE FUNCTION `nextval`(v_seq_name VARCHAR(50))
 RETURNS int
begin
    update sequence set current_val = current_val + increment_val  where seq_name = v_seq_name;
    return currval(v_seq_name);
end
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
